create definer = root@localhost trigger order_check
    before insert
    on `order`
    for each row
BEGIN
    DECLARE count INT;
    SELECT COUNT(*) INTO count FROM dewu.order WHERE item_sale_id = NEW.item_sale_id AND order_state <> 1;
    IF count > 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'The item has been chosen in one order';
    END IF;
END;

